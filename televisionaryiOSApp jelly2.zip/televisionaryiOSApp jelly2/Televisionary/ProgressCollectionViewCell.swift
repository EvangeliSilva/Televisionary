//
//  ProgressCollectionViewCell.swift
//  Televisionary
//
//  Created by Evangeli Silva on 3/26/17.
//  Copyright © 2017 Evangeli Silva. All rights reserved.
//

import UIKit

class ProgressCollectionViewCell: UICollectionViewCell {
    
}
