//
//  ProgressViewController.swift
//  Televisionary
//
//  Created by Evangeli Silva on 3/26/17.
//  Copyright © 2017 Evangeli Silva. All rights reserved.
//

import UIKit

class ProgressViewController: UIViewController {

    @IBOutlet weak var collection: UICollectionView!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        self.initCollectionView()
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    func initCollectionView() {
    
    }
   

}
